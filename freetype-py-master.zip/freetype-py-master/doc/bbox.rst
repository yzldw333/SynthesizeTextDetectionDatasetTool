.. currentmodule:: freetype

BBox
====
.. autoclass:: BBox
   :members:
