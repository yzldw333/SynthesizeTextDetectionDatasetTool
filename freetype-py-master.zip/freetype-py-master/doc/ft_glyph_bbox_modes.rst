FT_GLYPH_BBOX_MODES
===================

The mode how the values of FT_Glyph_Get_CBox are returned.

.. data:: FT_GLYPH_BBOX_UNSCALED	

  Return unscaled font units.

.. data:: FT_GLYPH_BBOX_SUBPIXELS

  Return unfitted 26.6 coordinates.

.. data:: FT_GLYPH_BBOX_GRIDFIT	

  Return grid-fitted 26.6 coordinates.

.. data:: FT_GLYPH_BBOX_TRUNCATE	

  Return coordinates in integer pixels.

.. data:: FT_GLYPH_BBOX_PIXELS	

  Return grid-fitted pixel coordinates.

