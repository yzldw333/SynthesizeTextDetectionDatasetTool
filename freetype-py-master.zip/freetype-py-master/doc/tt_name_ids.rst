TT_NAME_IDS
===========

Possible values of the 'name' identifier field in the name records of the TTF
'name' table. These values are platform independent.

.. data:: TT_NAME_ID_COPYRIGHT

.. data:: TT_NAME_ID_FONT_FAMILY

.. data:: TT_NAME_ID_FONT_SUBFAMILY

.. data:: TT_NAME_ID_UNIQUE_ID

.. data:: TT_NAME_ID_FULL_NAME

.. data:: TT_NAME_ID_VERSION_STRING

.. data:: TT_NAME_ID_PS_NAME

.. data:: TT_NAME_ID_TRADEMARK

.. data:: TT_NAME_ID_MANUFACTURER

.. data:: TT_NAME_ID_DESIGNER

.. data:: TT_NAME_ID_DESCRIPTION

.. data:: TT_NAME_ID_VENDOR_URL

.. data:: TT_NAME_ID_DESIGNER_URL

.. data:: TT_NAME_ID_LICENSE

.. data:: TT_NAME_ID_LICENSE_URL

.. data:: TT_NAME_ID_PREFERRED_FAMILY

.. data:: TT_NAME_ID_PREFERRED_SUBFAMILY

.. data:: TT_NAME_ID_MAC_FULL_NAME

.. data:: TT_NAME_ID_SAMPLE_TEXT

.. data:: TT_NAME_ID_CID_FINDFONT_NAME

.. data:: TT_NAME_ID_WWS_FAMILY

.. data:: TT_NAME_ID_WWS_SUBFAMILY

