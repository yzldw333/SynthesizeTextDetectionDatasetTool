.. currentmodule:: freetype

Outline
=======
.. autoclass:: Outline
   :members:
